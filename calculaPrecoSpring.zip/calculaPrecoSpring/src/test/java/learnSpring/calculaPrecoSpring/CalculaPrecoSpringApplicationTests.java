package learnSpring.calculaPrecoSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculaPrecoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
